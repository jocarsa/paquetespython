from mipaquete import primero
from mipaquete import segundo
from mipaquete import tercero

saluda()
