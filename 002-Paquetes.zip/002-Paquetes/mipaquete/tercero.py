def buenasNoches():
    print("Yo te digo buenas noches desde el modulo")
