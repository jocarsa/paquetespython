def despide():
    print("Yo te despido desde el modulo")
